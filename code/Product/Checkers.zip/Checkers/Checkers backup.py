import pygame
import pyautogui
import math
import random
import os
import CLI_Checkers
from os import path
from TypeEngine import typer
#add open move choices
pygame.init()
scrnw = int(1920)
scrnh = int(1080)
global screen
screen = pygame.display.set_mode((scrnw,scrnh), pygame.RESIZABLE)
colorblack = (0,0,0)
white = (255,255,255)
colorred = (255,0,0)
yellow = (255,255,0)
blue = (0,0,255)
apricot = (247,187,147)
brown = (113,61,47)
pygame.display.set_caption('Checkers')

def drawboard(x = 0, y = 0):
    ax = 0
    ay = 0
    size = int(boardsize/8)
    while True:
        pygame.draw.rect(screen, colorred, (int(x+ax),int(y+ay),int(size),int(size)), 0)
        ax = ax + size*2
        if ax == size*8:
            ax = size
            ay = ay + size
        if ax == size*9:
            ax = 0
            ay = ay + size
            if ay == size*8:
                break
    bx = size
    by = 0
    while True:
        pygame.draw.rect(screen, colorblack, (int(x+bx),int(y+by),int(size),int(size)), 0)
        bx = bx + size*2
        if bx == size*8:
            bx = size
            by = by + size
            if by == size*8:
                break
        if bx == size*9:
            bx = 0
            by = by + size

def pieces(x = 0, y = 0):
    global size
    size = int(boardsize/8)
    ax = size
    ay = 0
    global checkers
    checkers = []
    while True:
        checkers.append(piece(x+ax,y+ay, ax/size, ay/size, 'red'))
        ax = ax + size*2
        if ax == size*8:
            ax = size
            ay = ay + size
        if ax == size*9:
            ax = 0
            ay = ay + size
            if ay == size*8:
                break
        if ay == size*3:
            break
    bx = 0
    by = size*5
    while True:
        checkers.append(piece(x+bx,y+by, bx/size, by/size, 'black'))
        bx = bx + size*2
        if bx == size*8:
            bx = size
            by = by + size
            if by == size*8:
                break
        if bx == size*9:
            bx = 0
            by = by + size

def makeButtons():
    global buttons
##    buttons.append(button('undo', 9, 7))
##    buttons.append(button('redo', 10, 7))
    buttons.append(button('settings', 11, 7))
    buttons.append(button('save', 11, 0))
global buttons
buttons = []
def updatePieces(x = 0, y = 0):
    global size
    size = int(boardsize/8)
    i = 0
    while i < 24:
        pc = checkers[i]
        pc.setX()
        pc.setY()
        pc.show()
        i = i + 1
    i = 0
    while i < len(buttons):
        pc = buttons[i]
        pc.setX()
        pc.setY()
        pc.show()
        i = i + 1
def background():
    screen.blit(felt, (0,0))
    drawboard((scrnw-boardsize)/2.25,(scrnh-boardsize)/2)
    screen.blit(frame, (int(((scrnw-boardsize)/2-frame.get_width())/10),0))
    screen.blit(frame, (int(((scrnw-boardsize)/2-frame.get_width())/10),scrnh-frame.get_height()+scrnh/25))
    if mode == 'personvsperson':
        screen.blit(blackprsn, (int(scrnw*77/100),int(scrnh*9/10-blackprsn.get_height())))
        screen.blit(redprsn, (int(scrnw*77/100),int(scrnh/10)))
    if mode == 'personvsAI':
        screen.blit(blackprsn, (int(scrnw*77/100),int(scrnh*9/10-blackprsn.get_height())))
        screen.blit(redrobot, (int(scrnw*77/100),int(scrnh/10)))
    if mode == 'AIvsAI':
        screen.blit(blackrobot, (int(scrnw*77/100),int(scrnh*9/10-blackrobot.get_height())))
        screen.blit(redrobot, (int(scrnw*77/100),int(scrnh/10)))
def load():
    global felt
    global frame
    global redprsn
    global blackprsn
    global redrobot
    global blackrobot
    global pointer
    global boardsize
    felt = pygame.image.load(r'greenfelt.jpg')
    felt = pygame.transform.smoothscale(felt, (scrnw, scrnh))
    frame = pygame.image.load(r'GoldFrameTransparent.png')
    frame = pygame.transform.scale(frame, (int(scrnh*3/8), int(scrnh*3/8*(116/81))))
    redprsn = pygame.image.load(r'personiconred.png')
    redprsn = pygame.transform.scale(redprsn, (int(scrnh*1.5/8), int(scrnh*1.5/8)))
    blackprsn = pygame.image.load(r'personicon.png')
    blackprsn = pygame.transform.smoothscale(blackprsn, (int(scrnh*1.5/8), int(scrnh*1.5/8)))
    redrobot = pygame.image.load(r'redrobot.png')
    redrobot = pygame.transform.smoothscale(redrobot, (int(scrnh*1.5/8), int(scrnh*1.5/8*(360/377))))
    blackrobot = pygame.image.load(r'blackrobot.png')
    blackrobot = pygame.transform.smoothscale(blackrobot, (int(scrnh*1.5/8), int(scrnh*1.5/8*(360/377))))
    pointer = pygame.image.load(r'pointer.png')
    boardsize = int(scrnh*9/10)
def moveAI():
    global turn
    if turn == 0:
        firstmove = random.randint(0,6)
        if 0 <= firstmove <= 3:
            checkers[12+firstmove].valid(xx + (firstmove*2+1+0.25)*size, yy + 4*size)
        if 4 <= firstmove <= 6:
            checkers[13+firstmove-4].valid(xx + ((firstmove-4)*2+1+0.25)*size, yy + 4*size)
        x = int((abs(moves[-1][2]-7)+1)/2)
        y = abs(moves[-1][3]-7)*4
        xy = x + y
        x2 = int((abs(moves[-1][6]-7)+1)/2)
        y2 = abs(moves[-1][7]-7)*4
        xy2 = x2 + y2
        print(xy, xy2)
        makeMove(p.drawP(),turn, xy + '-' + xy2)#x , y, x2, y2, moves[-1][2], moves[-1][3], moves[-1][6], moves[-1][7])
    else:
        pass
    
class button():
    def __init__(self, name, xspot, yspot = 8):
        self.xspot = xspot
        self.yspot = yspot
        self.name = name
        self.selected = False
        if path.exists(r'' + name + '.png'):
            self.pc = pygame.image.load(r'' + name + '.png')
        else:
            self.pc = pygame.image.load(r'' + name + '.jpg')

    def do(self):
        global turn
        global undo
        global wasundo
        global redo
        global undolvl
        global moves
        global xx
        global yy
        global chng
        global screen
        if self.name == 'move':
            moveAI()
        if self.name == 'undo':
            chng = False
            if undolvl == len(moves):
                undolvl = undolvl
            else:
                undolvl = undolvl + 1
            if turn == 0:
                return
            print('UNDOLVL', undolvl)
            if not undo:
                chng = True
                tmpundolvl = undolvl
            undo = True
            wasundo = True
            redo = False
            if turn == 1:
                pass
            else:
                turn = moves[-undolvl][1]
            print('turn', turn, 'undolvl', undolvl)
            if moves[-undolvl][4]:
                checkers[moves[-undolvl][0]-1].unKing()
            if moves[-undolvl][5]:
                checkers[moves[-undolvl][0]-1].jumpValid(xx + (moves[-undolvl][2]+0.25)*size, yy + moves[-undolvl][3]*size)
            else:
                print("else", moves[-undolvl])
                checkers[moves[-undolvl][0]-1].valid(xx + (moves[-undolvl][2]+0.25)*size, yy + moves[-undolvl][3]*size)
                print(xx + (moves[-undolvl][2]+0.25)*size, yy + moves[-undolvl][3]*size)
            print('NEWUNDOLVL', undolvl)
            print('Turn after', turn, 'undolvl', undolvl)
            print(moves)
            undo = False
        if self.name == 'redo':
            print("redoing", undolvl)
            if undolvl > 1:
                undolvl = undolvl - 1
            if undolvl == 0:
                return
            else:
                undolvl = undolvl - 1
            redo = True
            turn = moves[-undolvl][1]
            print('turn', turn, 'undolvl', undolvl)
            
            if moves[-undolvl][4]:
                #check to reking
                checkers[moves[-undolvl][0]-1].unKing()
            if moves[-undolvl][5]:
                checkers[moves[-undolvl][0]-1].jumpValid(xx + (moves[-undolvl][6]+0.25)*size, yy + moves[-undolvl][7]*size)
            else:
                print("else")
                checkers[moves[-undolvl][0]-1].valid(xx + (moves[-undolvl][6]+0.25)*size, yy + moves[-undolvl][7]*size)
                print(xx + (moves[-undolvl][6]+0.25)*size, yy + moves[-undolvl][7]*size)
                print(moves[-undolvl][6], moves[-undolvl][7])
                print(moves)
        if self.name == 'save':
            rect = pygame.Rect(xx, yy, boardsize, boardsize)
            board = screen.subsurface(rect)
            pygame.image.save(board, r'board.png')
            board = pygame.image.load(r'board.png')
            save(board)
        if self.name == 'settings':
            while True:
                wh = pygame.display.get_window_size()
                scrnw = int(wh[0])
                scrnh = int(wh[0]*9/16)
                screen = pygame.display.set_mode((scrnw,scrnh), pygame.RESIZABLE)
                xx = (scrnw-boardsize)/2.25
                yy = (scrnh-boardsize)/2
                load()
                background()
                updatePieces()
                column = 0
                lessr = 153/(boardsize)
                r = 153
                lessg = 179/(boardsize)
                g = 179
                moreb = (255 - 237)/(boardsize)
                b = 237
                while column < boardsize + 1:
                    pygame.draw.line(screen, (r,g,b), (xx,yy+column), (xx+boardsize,yy+column), 1)
                    r = r - lessr
                    g = g - lessg
                    b = b + moreb
                    column = column + 1
                afont = pygame.font.SysFont('microsoftyaheimicrosoftyaheiui', int(scrnh/30))
                text = afont.render('Themes', True, (0, 0, 0))
                screen.blit(text, (xx, yy))
                for event in pygame.event.get():
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        mouse = pygame.mouse.get_pos()
                        for i in buttons:
                            if i.getX() <= mouse[0] < i.getX()+size and i.getY() <= mouse[1] < i.getY()+size:
                                choice = i
                                for j in buttons:
                                    if j.getSelect() and j != choice:
                                        j.select()
                                i.select()
                                if i == self:
                                    self.selected = False
                                    return
                                i.do()
                pygame.display.update()
                
        self.selected = False

    def getSelect(self):
        return self.selected

    def getX(self):
        return self.x

    def getY(self):
        return self.y

    def setX(self):
        self.x = xx + self.xspot*size

    def setY(self):
        self.y = yy + self.yspot*size

    def select(self):
        self.selected = True

    def show(self):
        length = int(boardsize/8*0.7)
        if self.name == 'move':
            length = int(boardsize/8*1.7)

        if self.selected and self.name != 'undo' and self.name != 'redo' and self.name != 'move':
            if path.exists(r'' + self.name + 'blue.png'):
                self.pc = pygame.image.load(r'' + self.name + 'blue.png')
            else:
                self.pc = pygame.image.load(r'' + self.name + 'blue.jpg')
        else:
            if path.exists(r'' + self.name + '.png'):
                self.pc = pygame.image.load(r'' + self.name + '.png')
            else:
                self.pc = pygame.image.load(r'' + self.name + '.jpg')
        self.pc = pygame.transform.smoothscale(self.pc, (length,length))
        if self.name == 'move':
            screen.blit(self.pc, (self.x + int(length/1.7 - length)/2, self.y + int((length/1.7 - length)/2)))
        else:
            screen.blit(self.pc, (self.x + int(length/0.7 - length)/2, self.y + int((length/0.7 - length)/2)))

class piece():

    number = 0
    redeaten = 0
    blackeaten = 0

    def __init__(self, x, y, xspot, yspot, color):
        self.pc = pygame.image.load(r'' + color + '.png')
        self.pc = pygame.transform.smoothscale(self.pc, (int(boardsize/8),int(boardsize/8)))
        self.x = int(x)
        self.y = int(y)
        self.xspot = xspot
        self.yspot = yspot
        self.color = color
        self.king = False
        self.eaten = False
        self.selected = False
        self.timeeaten = None
        self.eatxspot = None
        self.eatyspot = None
        piece.number = piece.number + 1
        self.number = piece.number
        screen.blit(self.pc, (self.x,self.y))

    def getX(self):
        return self.x

    def getY(self):
        return self.y

    def makeKing(self):
        self.king = True
        self.pc = pygame.image.load(r'' + self.color + 'king.png')
        self.pc = pygame.transform.smoothscale(self.pc, (int(scrnh/10),int(scrnh/10)))

    def unKing(self):
        self.king = False
        self.pc = pygame.image.load(r'' + self.color + '.png')
        self.pc = pygame.transform.smoothscale(self.pc, (int(scrnh/10),int(scrnh/10)))
        
    def setX(self):
        global size
        if not self.eaten:
            self.x = xx + self.xspot*size
        else:
            inby = int(scrnh/34)
            if self.color == 'red':
                self.x = (int(((scrnw-boardsize)/2-frame.get_width())/10) + inby) + (int(scrnh*3/8) - inby*2)/3*(self.timeeaten % 3)
            if self.color == 'black':
                self.x = (int(((scrnw-boardsize)/2-frame.get_width())/10) + inby) + (int(scrnh*3/8) - inby*2)/3*(self.timeeaten % 3)

    def setY(self):
        global size
        if not self.eaten:
            self.y = yy + self.yspot*size
        else:
            inby = int(scrnh/34)
            if self.color == 'red':
                self.y = (scrnh-frame.get_height()+scrnh/25 + inby) + (int(scrnh*3/8*(116/81)) - inby*4)/4*int(self.timeeaten / 3)
            if self.color == 'black':
                self.y = (0 + inby) + (int(scrnh*3/8*(116/81)) - inby*4)/4*int(self.timeeaten / 3)

    def getSelect(self):
        return self.selected

    def eat(self):
        self.eaten = True
        self.y = 0
        self.x = 0
        self.eatxspot = self.xspot
        self.eatyspot = self.yspot
        self.yspot = -2
        self.xspot = -2
        if self.color == 'red':
            self.timeeaten = piece.redeaten
            piece.redeaten += 1

        elif self.color == 'black':
            self.timeeaten = piece.blackeaten
            piece.blackeaten += 1

    def unEat(self):
        self.xspot = self.eatxspot
        self.yspot = self.eatyspot
        if self.color == 'red':
            self.timeeaten = None
            piece.redeaten -= 1

        elif self.color == 'black':
            self.timeeaten = None
            piece.blackeaten -= 1
        self.eaten = False

    def motion(self, oldx, oldy, chngsize):
        pygame.draw.rect(screen, (0,0,0), (oldx,oldy,size,size), 0)
        rect = pygame.Rect(xx, yy, boardsize, boardsize)
        board = screen.subsurface(rect)
        pygame.image.save(board, r'board.png')
        board = pygame.image.load(r'board.png')
        xf = 0
        yf = 0
        x = self.x - oldx
        y = self.y - oldy
        speed = 50
        grow = 3
        i = 0
        while not makemoves:
            screen.blit(board, (xx, yy))
            xf = xf + x/speed
            yf = yf + y/speed
            pygame.time.wait(2)
            self.pc = pygame.image.load(r'' + self.color + 'king'*self.king + '.png')
            self.pc = pygame.transform.smoothscale(self.pc, (int(scrnh/10+(-abs(i-speed/2)+speed/2)*grow*chngsize),int(scrnh/10+(-abs(i-speed/2)+speed/2)*grow*chngsize)))
            screen.blit(self.pc, (oldx + xf - (-abs(i-speed/2)+speed/2)*grow*chngsize/2, oldy + yf - (-abs(i-speed/2)+speed/2)*grow*chngsize/2))
            pygame.display.update()
            if i == speed:
                screen.blit(board, (xx, yy))
                screen.blit(self.pc, (self.x, self.y))
                pygame.display.update()
                break
            i = i + 1
    
    def select(self):
        self.selected = not self.selected

    def show(self):
        self.pc = pygame.transform.smoothscale(self.pc, (int(boardsize/8),int(boardsize/8)))
        screen.blit(self.pc, (self.x,self.y))
        if self.selected:
            pygame.draw.circle(screen, white, (int((self.x+(self.x+int(boardsize/8)))/2),int((self.y+(self.y+int(boardsize/8)))/2)), int(boardsize/8*0.4), int(scrnh/250))

    def valid(self, x, y):
        global turn
        global moved
        global undo
        global undolvl
        global moves
        global redo
        fix2 = 1
        if undo and undolvl == 0 and turn == 0:
            undo = False
        if self.color == 'red':
            fix2 = fix2*1
            if turn % 2 + undo == 0:
                return False
            fix = -1
        if self.color == 'black':
            if turn % 2 + undo == 1:
                return False
            fix = 1
        if undo:
            fix = fix*-1
            fix2 = 1
        if redo:
            fix = fix*1
            fix2 = 1
            
        xset = int((self.x-xx+0.25)/size-fix*redo*2)*size
        yset = int((self.y-yy)/size+fix*redo*2)*size
        oldx = self.x
        oldy = self.y
        oldxspot = self.xspot
        oldyspot = self.yspot
        boolean = False
        if not self.king:
            if yset == int((y-yy)/size)*size+size*fix and xset == int((x-xx)/size)*size+size*fix2:
                boolean = True
            elif yset == int((y-yy)/size)*size+size*fix and xset == int((x-xx)/size)*size-size*fix2:
                boolean = True
        if self.king:
            if yset == int((y-yy)/size)*size-size*fix and xset == int((x-xx)/size)*size+size*fix2:
                boolean = True
            elif yset == int((y-yy)/size)*size-size*fix and xset == int((x-xx)/size)*size-size*fix2:
                boolean = True
        if boolean:
            self.y = int((y-yy)/size)*size+yy
            self.x = int((x-xx)/size)*size+xx
            self.yspot = int((y-yy)/size)
            self.xspot = int((x-xx)/size)
            if not self.king and ((self.yspot == 0 and self.color == 'black') or (self.yspot == 7 and self.color == 'red')):
                self.makeKing()
            turn = turn + 1
            if undo:
                turn = turn - 2 + redo
            self.motion(oldx, oldy, False)
        moved = True
        if not undo and not redo and boolean and not makemoves:
            undolvl = 0
            moves.append([self.number, turn, oldxspot, oldyspot, self.king, False, self.xspot, self.yspot])
        return boolean

    def jumpValid(self, x, y):
        global turn
        global moved
        global undo
        global undolvl
        global redo
        global moves
        minusturn = False
        fix2 = 1
        if self.color == 'red':
            fix2 = fix2*1
            if turn % 2 + undo == 0:
                minusturn = True
                if moved:
                    return False
            fix = -1
        if self.color == 'black':
            if turn % 2 + undo == 1:
                minusturn = True
                if moved:
                    return False
            fix = 1
        if undo:
            fix = fix*-1
            fix2 = -1
        xset = int((self.x-xx+0.25)/size)*size
        yset = int((self.y-yy)/size)*size
        oldx = self.x
        oldy = self.y
        oldxspot = self.xspot
        oldyspot = self.yspot
        boolean = False
        if yset == int((y-yy)/size)*size+size*fix*2 and xset == int((x-xx)/size)*size+size*fix2*2:
            boolean = True
        elif yset == int((y-yy)/size)*size+size*fix*2 and xset == int((x-xx)/size)*size-size*fix2*2:
            boolean = True
        if self.king:
            if yset == int((y-yy)/size)*size-size*fix*2 and xset == int((x-xx)/size)*size+size*fix2*2:
                boolean = True
            elif yset == int((y-yy)/size)*size-size*fix*2 and xset == int((x-xx)/size)*size-size*fix2*2:
                boolean = True
        eatboolean = False
        if boolean:
            self.y = int((y-yy)/size)*size+yy
            self.x = int((x-xx)/size)*size+xx
            self.yspot = int((y-yy)/size)
            self.xspot = int((x-xx)/size)
        if undo and turn > 0 and moves[-undolvl][5]:
            checkers[moves[-undolvl-undo][0]-1].unEat()
        for checker in checkers:
            if checker.color != self.color and (xset+xx < checker.getX() < self.x or xset+xx > checker.getX() > self.x) and (yset+yy < checker.getY() < self.y or yset+yy > checker.getY() > self.y):
                if undo:
                    pass
                else:
                    checker.eat()
                eatboolean = True
                break
        if not eatboolean and not undo:
            self.x = oldx
            self.y = oldy
            self.xspot = oldxspot
            self.yspot = oldyspot
            turn = turn - 1
            boolean = False

        else:
            self.y = int((y-yy)/size)*size+yy
            self.x = int((x-xx)/size)*size+xx
            self.yspot = int((y-yy)/size)
            self.xspot = int((x-xx)/size)
            if not self.king and ((self.yspot == 0 and self.color == 'black') or (self.yspot == 7 and self.color == 'red')):
                self.makeKing()
            turn = turn + 1
            if undo:
                turn = turn - 2 + redo
            self.motion(oldx, oldy, True)
            if minusturn:
                turn = turn - 1
        moved = False
        if not undo and boolean and not makemoves:
            undolvl = 0
            moves.append([self.number, turn, oldxspot, oldyspot, self.king, True, self.xspot, self.yspot])
        return boolean
def savetofile(title, board):
    global turn
    global moved
    global undolvl
    global undo
    global redo
    global moves
    global wasundo
    global mode
    if os.path.exists(r'games/'):
        pass
    else:
        os.mkdir(r'games')
    path = 'games/'
    title = ''.join(title)
    filename = title + ".txt"
    fullpath = os.path.join(path, filename)
    file = open(fullpath, "w")
    file.write(str(moves) + '\n')
    file.write(str(len(moves)) + '\n')
    file.write(str(turn) + '\n')
    file.write(str(moved) + '\n')
##    file.write(str(undolvl) + '\n')
##    file.write(str(undo) + '\n')
##    file.write(str(redo) + '\n')
##    file.write(str(wasundo) + '\n')
    file.write(str(mode) + '\n')
    file.close()
    pygame.image.save(board, r'' + path + title + ' board.png')
    

def save(board):
    title = []
    presssave = False
    while True:
        wh = pygame.display.get_window_size()
        scrnw = int(wh[0])
        scrnh = int(wh[0]*9/16)
        screen = pygame.display.set_mode((scrnw,scrnh), pygame.RESIZABLE)          
        firstload()
        if presssave:
            savetofile(title, board)
        savebackground(title)
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                mods = pygame.key.get_mods()
                if event.key == pygame.K_BACKSPACE:
                    if len(title) > 0:
                        del title[-1]
                elif event.key == pygame.K_RETURN:
                    presssave = True
                elif event.key == pygame.K_SPACE:
                    title.append(' ')
                elif event.key == pygame.K_TAB:
                    return title.append('    ')
                elif event.key == pygame.K_0:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append(')')
                    else:
                        title.append('0')

                elif event.key == pygame.K_1:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('!')
                    else:
                        title.append('1')

                elif event.key == pygame.K_2:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('@')
                    else:
                        title.append('2')

                elif event.key == pygame.K_3:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('#')
                    else:
                        title.append('3')

                elif event.key == pygame.K_4:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('$')
                    else:
                        title.append('4')

                elif event.key == pygame.K_5:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('%')
                    else:
                        title.append('5')

                elif event.key == pygame.K_6:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('^')
                    else:
                        title.append('6')

                elif event.key == pygame.K_7:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('&')
                    else:
                        title.append('7')

                elif event.key == pygame.K_8:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('*')
                    else:
                        title.append('8')

                elif event.key == pygame.K_9:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('(')
                    else:
                        title.append('9')

                elif event.key == pygame.K_a:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('A')
                    else:
                        title.append('a')

                elif event.key == pygame.K_b:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('B')
                    else:
                        title.append('b')

                elif event.key == pygame.K_c:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('C')
                    else:
                        title.append('c')

                elif event.key == pygame.K_d:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('D')
                    else:
                        title.append('d')

                elif event.key == pygame.K_e:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('E')
                    else:
                        title.append('e')

                elif event.key == pygame.K_f:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('F')
                    else:
                        title.append('f')

                elif event.key == pygame.K_g:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('G')
                    else:
                        title.append('g')

                elif event.key == pygame.K_h:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('H')
                    else:
                        title.append('h')

                elif event.key == pygame.K_i:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('I')
                    else:
                        title.append('i')

                elif event.key == pygame.K_j:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('J')
                    else:
                        title.append('j')

                elif event.key == pygame.K_k:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('K')
                    else:
                        title.append('k')

                elif event.key == pygame.K_l:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('L')
                    else:
                        title.append('l')

                elif event.key == pygame.K_m:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('M')
                    else:
                        title.append('m')

                elif event.key == pygame.K_n:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('N')
                    else:
                        title.append('n')

                elif event.key == pygame.K_o:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('O')
                    else:
                        title.append('o')

                elif event.key == pygame.K_p:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('P')
                    else:
                        title.append('p')

                elif event.key == pygame.K_q:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('Q')
                    else:
                        title.append('q')

                elif event.key == pygame.K_r:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('R')
                    else:
                        title.append('r')

                elif event.key == pygame.K_s:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('S')
                    else:
                        title.append('s')

                elif event.key == pygame.K_t:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('T')
                    else:
                        title.append('t')

                elif event.key == pygame.K_u:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('U')
                    else:
                        title.append('u')

                elif event.key == pygame.K_v:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('V')
                    else:
                        title.append('v')

                elif event.key == pygame.K_w:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('W')
                    else:
                        title.append('w')

                elif event.key == pygame.K_x:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('X')
                    else:
                        title.append('x')

                elif event.key == pygame.K_y:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('Y')
                    else:
                        title.append('y')

                elif event.key == pygame.K_z:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                        title.append('Z')
                    else:
                        title.append('z')

                elif event.key == pygame.K_QUOTE:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('"')
                    else:
                        title.append("'")

                elif event.key == pygame.K_QUOTEDBL:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('"')
                    else:
                        title.append("'")
                elif event.key == pygame.K_PLUS:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('+')
                    else:
                        title.append('=')

                elif event.key == pygame.K_EQUALS:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('+')
                    else:
                        title.append('=')

                elif event.key == pygame.K_MINUS:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('_')
                    else:
                        title.append('-')

                elif event.key == pygame.K_PERIOD:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('>')
                    else:
                        title.append('.')

                elif event.key == pygame.K_GREATER:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('>')
                    else:
                        title.append('.')

                elif event.key == pygame.K_SLASH:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('?')
                    else:
                        title.append('/')

                elif event.key == pygame.K_QUESTION:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('?')
                    else:
                        title.append('/')

                elif event.key == pygame.K_COLON:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append(':')
                    else:
                        title.append(';')

                elif event.key == pygame.K_SEMICOLON:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append(':')
                    else:
                        title.append(';')

                elif event.key == pygame.K_LESS:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('<')
                    else:
                        title.append(',')

                elif event.key == pygame.K_COMMA:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('<')
                    else:
                        title.append(',')

                elif event.key == pygame.K_LEFTBRACKET:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('{')
                    else:
                        title.append('[')

                elif event.key == pygame.K_RIGHTBRACKET:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('}')
                    else:
                        title.append(']')

                elif event.key == pygame.K_BACKSLASH:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('|')
                    else:
                        title.append('\\')

                elif event.key == pygame.K_BACKQUOTE:
                    if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                        title.append('~')
                    else:
                        title.append('`')

def savebackground(title):
    screen.blit(felt, (0,0))
    afont = pygame.font.SysFont('microsoftyaheimicrosoftyaheiui', int(scrnh/18))
    title = ''.join(title)
    text = afont.render(title, True, (0, 0, 0))
    pygame.draw.line(screen, (0,0,0), (scrnw/50,scrnh*95/100), (scrnw*49/50,scrnh*95/100), 5)
    screen.blit(text, (scrnw/50, scrnh*85/100))

def firstload():
    global robot
    global felt
    global play
    global playpress
    global rules
    global rulespress
    global black
    global blackking
    global red
    global redking
    global pclist
    global piecesize
    global folder
    global pvsp
    global pvsAI
    global AIvsAI
    robot = pygame.image.load(r'robot.png')
    robot = pygame.transform.smoothscale(robot, (int(robot.get_width()*scrnh/1000),int(robot.get_height()*scrnh/1000)))
    robot = pygame.transform.flip(robot, True, False)
    felt = pygame.image.load(r'greenfelt.jpg')
    felt = pygame.transform.smoothscale(felt, (scrnw, scrnh))
    play = pygame.image.load(r'play.png')
    play = pygame.transform.smoothscale(play, (int(play.get_width()*scrnh/3000), int(play.get_height()*scrnh/3000)))
    playpress = pygame.image.load(r'playpress.png')
    playpress = pygame.transform.smoothscale(playpress, (int(playpress.get_width()*scrnh/3000), int(playpress.get_height()*scrnh/3000)))
    rules = pygame.image.load(r'rules.png')
    rules = pygame.transform.smoothscale(rules, (int(rules.get_width()*scrnh/4800), int(rules.get_height()*scrnh/4800)))
    rulespress = pygame.image.load(r'rulespress.png')
    rulespress = pygame.transform.smoothscale(rulespress, (int(rulespress.get_width()*scrnh/4800), int(rulespress.get_height()*scrnh/4800)))
    black = pygame.image.load(r'black.png')
    piecesize = int(black.get_width()*scrnh/1000)
    black = pygame.transform.smoothscale(black, (piecesize, piecesize))
    blackking = pygame.image.load(r'blackking.png')
    blackking = pygame.transform.smoothscale(blackking, (piecesize, piecesize))
    red = pygame.image.load(r'red.png')
    red = pygame.transform.smoothscale(red, (piecesize, piecesize))
    redking = pygame.image.load(r'redking.png')
    redking = pygame.transform.smoothscale(redking, (piecesize, piecesize))
    pclist = [black, blackking, red, redking]
    folder = pygame.image.load(r'open.png')
    folder = pygame.transform.smoothscale(folder, (int(scrnh/10), int(scrnh/10)))
    pvsp = pygame.image.load(r'personvsperson.png')
    pvsp = pygame.transform.smoothscale(pvsp, (int(scrnh/4.5), int(scrnh/4.5)))
    pvsAI = pygame.image.load(r'personvsAI.png')
    pvsAI = pygame.transform.smoothscale(pvsAI, (int(scrnh/4.5), int(scrnh/4.5)))
    AIvsAI = pygame.image.load(r'AIvsAI.png')
    AIvsAI = pygame.transform.smoothscale(AIvsAI, (int(scrnh/4.5), int(scrnh/4.5)))
def firstbackground(hover, spin, pressplay, pressrules, chngrobot, mode):
    global chngpc
    global prevspin
    global n
    global m
    global pos
    global posaccel
    global dobreak
    global count
    global move
    if makemoves:
        return True
    screen.blit(felt, (0,0))
    afont = pygame.font.SysFont('microsoftyaheimicrosoftyaheiui', int(scrnh/10))
    text = afont.render('Smart Checkers', True, (0, 0, 0))
    screen.blit(text, (scrnw/2-text.get_width()/2, scrnh/100))
    if prevspin < spin and prevspin > 0 and spin < 0.1:
        chngpc += 1
    pclist[chngpc%4] = pygame.transform.smoothscale(pclist[chngpc%4], (int(piecesize*spin), int(piecesize)))
    screen.blit(pclist[chngpc%4], (int(scrnw/2-piecesize*spin/2),int(scrnh/4)))
    if not pressplay:
        showplay = play
    if pressplay:
        showplay = playpress
    screen.blit(showplay, (int(scrnw/2 - play.get_width()/2),int(scrnh*7/10)))
    if not pressrules:
        showrules = rules
    if pressrules:
        showrules = rulespress
    screen.blit(showrules, (int(scrnw/2 - rules.get_width()/2),int(scrnh*8.6/10)))
    prevspin = spin
    screen.blit(folder, (int(scrnw-scrnh/60-folder.get_width()), int(scrnh-scrnh/60-folder.get_height())))
    size = robot.get_width()
    if chngrobot:
        fromx1 = hover*0 +pos*(1*math.cos(0.36*(move+(-125)*0.0174532925)))+scrnw/2
        fromy1 = hover*0 +pos*(1*math.sin(0.36*(move+(-125)*0.0174532925)))+scrnh/2
        screen.blit(robot, (int(fromx1)-size/2+(size-int(size*5/4))/2,int(fromy1)-size/2+(size-int(size*5/4))/2))
        pygame.display.update()
        move = move + 0.01 + n
        if dobreak == True:
            return True
        if pos <= 0:
            pos = 0
            dobreak = True
        else:
            pos = pos - 1 - posaccel
        posaccel = posaccel + 2
        n = n + m + 0.01
        m = m + 0.005
    else:
        screen.blit(robot, ((scrnw/20,int(scrnh/2-robot.get_height()/2)+hover)))
    screen.blit(pvsp, ((int(scrnw - scrnw/4),int(scrnh/4.5*1))))
    screen.blit(pvsAI, ((int(scrnw - scrnw/4),int(scrnh/4.5*2+scrnh/100))))
    screen.blit(AIvsAI, ((int(scrnw - scrnw/4),int(scrnh/4.5*3+scrnh/50))))
    if mode == 'personvsperson':
        pygame.draw.rect(screen, (0,0,0), (int(scrnw - scrnw/4),int(scrnh/4.5*1),int(scrnh/4.5),int(scrnh/4.6)), int(scrnh/200))
    if mode == 'personvsAI':
        pygame.draw.rect(screen, (0,0,0), (int(scrnw - scrnw/4),int(scrnh/4.5*2+scrnh/100),int(scrnh/4.5),int(scrnh/4.6)), int(scrnh/200))
    if mode == 'AIvsAI':
        pygame.draw.rect(screen, (0,0,0), (int(scrnw - scrnw/4),int(scrnh/4.5*3+scrnh/50),int(scrnh/4.5),int(scrnh/4.6)), int(scrnh/200))


    return False

def showrules():
    presshome = False
    while True:
        wh = pygame.display.get_window_size()
        scrnw = int(wh[0])
        scrnh = int(wh[0]*9/16)
        screen = pygame.display.set_mode((scrnw,scrnh), pygame.RESIZABLE)
        felt = pygame.image.load(r'greenfelt.jpg')
        felt = pygame.transform.smoothscale(felt, (scrnw, scrnh))
        screen.blit(felt, (0,0))
        wrules = pygame.image.load(r'writtenrules.png')
        wrules = pygame.transform.smoothscale(wrules, (scrnw, int(scrnw*47.68/97.64)))
        screen.blit(wrules, (0, 0))
        home = pygame.image.load(r'home.png')
        home = pygame.transform.smoothscale(home, (int(scrnh/10), int(scrnh/10)))
        screen.blit(home, (int(scrnw-scrnh/60-home.get_width()), int(scrnh-scrnh/60-home.get_height())))
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            elif event.type == pygame.WINDOWEVENT_MINIMIZED:
                scrnw = tempscrnw
                scrnh = tempscrnh
            elif event.type == pygame.WINDOWEVENT_MAXIMIZED:
                tempscrnw = scrnw
                tempscrnh = scrnh
                root.state('zoomed')
            mouse = pygame.mouse.get_pos()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if int(scrnw-scrnh/60-home.get_width()) <= mouse[0] <= int(scrnw-scrnh/60) and int(scrnh-scrnh/60-home.get_height()) <= mouse[1] <= int(scrnh-scrnh/60):
                    presshome = True
            elif event.type == pygame.MOUSEBUTTONUP and int(scrnw-scrnh/60-home.get_width()) <= mouse[0] <= int(scrnw-scrnh/60) and int(scrnh-scrnh/60-home.get_height()) <= mouse[1] <= int(scrnh-scrnh/60):
                if presshome:
                    return
            elif event.type == pygame.MOUSEBUTTONUP:
                presshome = False
def displayGame(board, movenum, i, x, maxofi, w, h, game, difmode):
    x = int(x)
    ysize = 3.5
    global home
    board = pygame.transform.smoothscale(board, (int(h/ysize*int(1) - h/250*2), int(h/ysize*int(1) - h/250*2)))
    screen.blit(board, (int(w/500 + w/2*(((i - 1)/2) % 2)),int(h/250 + h/ysize*int((i - 1)/2/2))+x))
    pygame.draw.rect(screen, (255,255,255), (int(w/500 + w/2*(((i - 1)/2) % 2)),int(h/250 + h/ysize*int((i - 1)/2/2))+x,int(w/2 - w/500*2),int(h/ysize*int(1) - h/250*2)), int(h/200))
    afont = pygame.font.SysFont('arialbold', int(h/16))
    text = afont.render('P1', True, (0, 0, 0))
    screen.blit(text, (int(w/500 + w/2*(3/5.1 - 0.05) + w/2*(((i - 1)/2) % 2)),int(h/250 + h/ysize/2 + h/ysize*int((i - 1)/2/2))+x))
    text = afont.render('P2', True, (0, 0, 0))
    screen.blit(text, (int(w/500 + w/2*(4/5.1 - 0.05) + w/2*(((i - 1)/2) % 2)),int(h/250 + h/ysize/2 + h/ysize*int((i - 1)/2/2))+x))
    p1 = (int(w/500 + w/2*(3/5.1) + w/2*(((i - 1)/2) % 2)),int(h/250 + h/ysize/2 + h/ysize*int((i - 1)/2/2))+x)
    p2 = (int(w/500 + w/2*(4/5.1) + w/2*(((i - 1)/2) % 2)),int(h/250 + h/ysize/2 + h/ysize*int((i - 1)/2/2))+x)
    psize = h*13/100
    redprsn = pygame.image.load(r'personiconred.png')
    redprsn = pygame.transform.scale(redprsn, (int(psize), int(psize)))
    blackprsn = pygame.image.load(r'personicon.png')
    blackprsn = pygame.transform.smoothscale(blackprsn, (int(psize), int(psize)))
    redrobot = pygame.image.load(r'redrobot.png')
    redrobot = pygame.transform.smoothscale(redrobot, (int(psize), int(psize*(360/377))))
    blackrobot = pygame.image.load(r'blackrobot.png')
    blackrobot = pygame.transform.smoothscale(blackrobot, (int(psize), int(psize*(360/377))))
    if difmode == 'personvsperson':
        screen.blit(blackprsn, p1)
        screen.blit(redprsn, p2)
    if difmode == 'personvsAI':
        screen.blit(blackprsn, p1)
        screen.blit(redrobot, p2)
    if difmode == 'AIvsAI':
        screen.blit(blackrobot, p1)
        screen.blit(redrobot, p2)
    afont = pygame.font.SysFont('malgungothic', int(h/22))
    game = game[:-4]
    if len(game) > 15:
        game = game[:14] + '...'
    text = afont.render(game, True, (0, 0, 0))
    screen.blit(text, (int(w/500 + w/2*(((i - 1)/2) % 2) + (h/ysize*int(1) - h/250*2) + w/250),int(h/ysize*int((i - 1)/2/2))+x))
    afont = pygame.font.SysFont('malgungothicsemilight', int(h/25))
    text = afont.render('Moves: ' + movenum[:-1], True, (0, 0, 0))
    screen.blit(text, (int(w/500 + w/2*(((i - 1)/2) % 2) + (h/ysize*int(1) - h/250*2) + w/250),int(h/ysize*0.24 + h/ysize*int((i - 1)/2/2))+x))
    for event in pygame.event.get():
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                mouse = pygame.mouse.get_pos()
                for j in range(1, int(maxofi), 2):
                    if (int(w/500 + w/2*(((j - 1)/2) % 2)) <= mouse[0] <= int(w/500 + w/2*(((j - 1)/2) % 2)) + int(w/2 - w/500*2) and int(h/250 + h/ysize*int((j - 1)/2/2))+x <= mouse[1] <= int(h/250 + h/ysize*int((j - 1)/2/2))+x+int(h/ysize*int(1) - h/250*2)) and not (int(w-scrnh/60-home.get_width()) <= mouse[0] <= int(w-scrnh/60) and int(scrnh-scrnh/60-home.get_height()) <= mouse[1] <= int(scrnh-scrnh/60)):
    ##                    print(j)
                        return j
    return -1
def opengame(gamenum):
    i = 0
    global moves
    global turn
    global mode
    global moved
    for game in os.listdir(r'games/'):
        i = i + 1
        if i - 1 == gamenum:
            path = 'games/'
            filename = game
            fullpath = os.path.join(path, filename)
            file = open(fullpath, "r")
            moves = file.readline()
##            print(moves, fullpath)
            file.readline()
##            turn = file.readline()
            moved = file.readline()
            mode = file.readline()
            file.close()
            break
def showfolder():
    presshome = False
    x = 0
    maxofi = 0
    global home
    while True:
        wh = pygame.display.get_window_size()
        scrnw = int(wh[0])
        scrnh = int(wh[0]*9/16)
        screen = pygame.display.set_mode((scrnw,scrnh), pygame.RESIZABLE)
        felt = pygame.image.load(r'greenfelt.jpg')
        felt = pygame.transform.smoothscale(felt, (scrnw, scrnh))
        screen.blit(felt, (0,0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            elif event.type == pygame.WINDOWEVENT_MINIMIZED:
                scrnw = tempscrnw
                scrnh = tempscrnh
            elif event.type == pygame.WINDOWEVENT_MAXIMIZED:
                tempscrnw = scrnw
                tempscrnh = scrnh
                root.state('zoomed')
            mouse = pygame.mouse.get_pos()
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse = pygame.mouse.get_pos()
                if int(scrnw-scrnh/60-home.get_width()) <= mouse[0] <= int(scrnw-scrnh/60) and int(scrnh-scrnh/60-home.get_height()) <= mouse[1] <= int(scrnh-scrnh/60):
                    presshome = True
            elif event.type == pygame.MOUSEBUTTONUP and int(scrnw-scrnh/60-home.get_width()) <= mouse[0] <= int(scrnw-scrnh/60) and int(scrnh-scrnh/60-home.get_height()) <= mouse[1] <= int(scrnh-scrnh/60):
                if presshome:
                    return False
            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 5:
                    if -(int(maxofi/2)-6)*scrnh/3.5 < x:
                        x = x - scrnh/10
                    if -(int(maxofi/2)-6)*scrnh/3.5 > x:
                        x = -(int(maxofi/2)-6)*scrnh/3.5
                if event.button == 4:
                    if x == 0:
                        pass
                    elif x + scrnh/5 >= 0:
                        x = 0
                    else:
                        x = x + scrnh/5
                presshome = False
        if os.path.exists(r'games/'):
            i = 0

            for game in os.listdir(r'games/'):
                if i % 2 == 0:
                    board = pygame.image.load(r'games/' + game)
                if i % 2 == 1:
                    file = open(r'games/' + game, "r")
                    file.readline()
                    movenum = file.readline()
                    file.readline()
                    file.readline()
                    difmode = file.readline()
                    difmode = difmode[:-1]
                    file.close()
                    gamechoice = displayGame(board, movenum, i, x, maxofi, scrnw, scrnh, game, difmode)
                    if gamechoice != -1:
                        opengame(gamechoice)
                        return True
                i = i + 1
                if i > maxofi:
                    maxofi = i
        
        home = pygame.image.load(r'home.png')
        home = pygame.transform.smoothscale(home, (int(scrnh/10), int(scrnh/10)))
        screen.blit(home, (int(scrnw-scrnh/60-home.get_width()), int(scrnh-scrnh/60-home.get_height())))
        pygame.display.update()
        
        
move = 0
hmv = 250
updown = False
global chngpc
firstload()
pressplay = False
pressrules = False
pressfolder = False
stop = False
chngpc = 0
global prevspin
chngrobot = False
prevspin = 0
##global n
##global m
##global pos
##global posaccel
##global dobreak
##global count
n = 0
m = 0
posaccel = 0
dobreak = False
count = 0
move = 0
global mode
mode = 'personvsperson'
makemoves = False
while not stop:
    if not chngrobot:
        pos = scrnw/3
    hover = 100*math.sin(move/hmv*math.pi*7)
    wh = pygame.display.get_window_size()
    scrnw = int(wh[0])
    scrnh = int(wh[0]*9/16)
    screen = pygame.display.set_mode((scrnw,scrnh), pygame.RESIZABLE)          
    firstload()
    spin = math.sin(move/hmv*math.pi*7)**2
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        elif event.type == pygame.WINDOWEVENT_MINIMIZED:
            scrnw = tempscrnw
            scrnh = tempscrnh
        elif event.type == pygame.WINDOWEVENT_MAXIMIZED:
            tempscrnw = scrnw
            tempscrnh = scrnh
            root.state('zoomed')
        mouse = pygame.mouse.get_pos()
        if event.type == pygame.MOUSEBUTTONDOWN:
            if int(scrnw/2 - play.get_width()/2) <= mouse[0] <= int(scrnw/2 - play.get_width()/2) + play.get_width() and int(scrnh*7/10) <= mouse[1] <= int(scrnh*7/10) + play.get_height():
                pressplay = True
            if int(scrnw/2 - rules.get_width()/2) <= mouse[0] <= int(scrnw/2 - rules.get_width()/2) + rules.get_width() and int(scrnh*8.6/10) <= mouse[1] <= int(scrnh*8.6/10) + rules.get_height():
                pressrules = True
            if int(scrnw-scrnh/60-folder.get_width()) <= mouse[0] <= int(scrnw-scrnh/60) and int(scrnh-scrnh/60-folder.get_height()) <= mouse[1] <= int(scrnh-scrnh/60):
                pressfolder = True
            if int(scrnw - scrnw/4) <= mouse[0] <= int(scrnw - scrnw/4 + scrnh/4.5) and int(scrnh/4.5*1) <= mouse[1] <= int(scrnh/4.5*1 + scrnh/4.5):
                mode = 'personvsperson'
            if int(scrnw - scrnw/4) <= mouse[0] <= int(scrnw - scrnw/4 + scrnh/4.5) and int(scrnh/4.5*2+scrnh/100) <= mouse[1] <= int(scrnh/4.5*2+scrnh/100 + scrnh/4.5):
                mode = 'personvsAI'
            if int(scrnw - scrnw/4) <= mouse[0] <= int(scrnw - scrnw/4 + scrnh/4.5) and int(scrnh/4.5*3+scrnh/50) <= mouse[1] <= int(scrnh/4.5*3+scrnh/50 + scrnh/4.5):
                mode = 'AIvsAI'
        if event.type == pygame.MOUSEBUTTONUP and (int(scrnw/2 - play.get_width()/2) <= mouse[0] <= int(scrnw/2 - play.get_width()/2) + play.get_width() and int(scrnh*7/10) <= mouse[1] <= int(scrnh*7/10) + play.get_height()):
            chngrobot = True
            pressrules = False
        elif event.type == pygame.MOUSEBUTTONUP and int(scrnw/2 - rules.get_width()/2) <= mouse[0] <= int(scrnw/2 - rules.get_width()/2) + rules.get_width() and int(scrnh*8.6/10) <= mouse[1] <= int(scrnh*8.6/10) + rules.get_height():
            pressrules = False
            showrules()
        elif event.type == pygame.MOUSEBUTTONUP and int(scrnw-scrnh/60-folder.get_width()) <= mouse[0] <= int(scrnw-scrnh/60) and int(scrnh-scrnh/60-folder.get_height()) <= mouse[1] <= int(scrnh-scrnh/60):
            makemoves = showfolder()
            if makemoves:
                pressplay = True
                chngrobot = True
        elif event.type == pygame.MOUSEBUTTONUP:
            pressplay = False
            pressrules = False
            pressfolder = False
    stop = firstbackground(hover, spin, pressplay, pressrules, chngrobot, mode)
    pygame.display.update()
    move = move + 1

if mode == 'AIvsAI':
    buttons.append(button('move', 9, 3.5))
    

wh = pygame.display.get_window_size()
tempscrnw = int(wh[0])
tempscrnh = int(wh[0]*9/16)
load()
pieces((scrnw-boardsize)/2,(scrnh-boardsize)/2)
makeButtons()
choice = None
global xx
global yy
global turn
global moved
global undolvl
global undo
global redo
global moves
global wasundo
wasundo = False
undo = False
undolvl = 0
turn = 0
redo = False
if not makemoves:
    moves = []
    moved = False
else:
    moves = moves[2:-3]
    moves = [list(map(str, x.split(", "))) for x in moves.split("], [")]
i = 0
if str(moves) == "[['']]":
    moves = []
for x in moves:
    if x[4] == 'True':
        four = True
    else:
        four = False
    if x[5] == 'True':
        five = True
    else:
        five = False

    moves[i] = [int(x[0]),int(x[1]),int(float(x[2])),int(float(x[3])),four,five,int(x[6]),int(x[7])]
    i = i + 1
    
    
i = 0
while makemoves and i < len(moves):
    xx = (scrnw-boardsize)/2.25
    yy = (scrnh-boardsize)/2
    if moves[i][5]:
        checkers[moves[i][0]-1].jumpValid(xx + (moves[i][6]+0.25)*size, yy + moves[i][7]*size)
    else:
        checkers[moves[i][0]-1].valid(xx + (moves[i][6]+0.25)*size, yy + moves[i][7]*size)
    i = i + 1
makemoves = False
while True:
    xx = (scrnw-boardsize)/2.25
    yy = (scrnh-boardsize)/2
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        elif event.type == pygame.WINDOWEVENT_MINIMIZED:
            scrnw = tempscrnw
            scrnh = tempscrnh
        elif event.type == pygame.WINDOWEVENT_MAXIMIZED:
            tempscrnw = scrnw
            tempscrnh = scrnh
            root.state('zoomed')
        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse = pygame.mouse.get_pos()
            tmpundolvl = undolvl
            for i in buttons:
                if i.getX() <= mouse[0] < i.getX()+size and i.getY() <= mouse[1] < i.getY()+size:
                    choice = i
                    for j in buttons:
                        if j.getSelect() and j != choice:
                            j.select()
                    i.select()
                    i.do()
            for i in checkers:
                if i.getX() <= mouse[0] < i.getX()+size and i.getY() <= mouse[1] < i.getY()+size:
                    choice = i
                    for j in checkers:
                        if j.getSelect() and j != choice:
                            j.select()
                    i.select()
            if choice != None and choice.getSelect() and abs(choice.xspot - (int((mouse[0]-xx)/size))) == 2 and abs(choice.yspot - (int((mouse[1]-yy)/size))) == 2:
                undolvl = 0
                if undo and redo:
                    undo = False
                    redo = False
                if choice.jumpValid(mouse[0], mouse[1]):
                    if wasundo:
                        del moves[-1]
                    moves = moves[undolvl:]
                    undo = False
                    wasundo = False
                    redo = False
            elif choice != None and choice.getSelect() and not(choice.getX() <= mouse[0] < choice.getX()+size and choice.getY() <= mouse[1] < choice.getY()+size):
                undolvl = 0
                if undo and redo:
                    undo = False
                    redo = False
                if choice.valid(mouse[0], mouse[1]):
                    if wasundo:
                        del moves[-1]
                    moves = moves[undolvl:]
                    undo = False
                    wasundo = False
                    redo = False
    wh = pygame.display.get_window_size()
    scrnw = int(wh[0])
    scrnh = int(wh[0]*9/16)
    screen = pygame.display.set_mode((scrnw,scrnh), pygame.RESIZABLE)
    load()
    background()
    updatePieces((scrnw-boardsize)/2,(scrnh-boardsize)/2)
    pygame.display.update()


    
