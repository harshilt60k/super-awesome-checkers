import pygame
import pyautogui
def typer(mod, pyevnt, evnt, k):
    for event in pyevnt:
        pygame.key.set_repeat(0, 100)
        if event.type == evnt:
            event.key = k
            mods = mod
##            print(mods)
            if event.key == pygame.K_BACKSPACE:
                del title[-1]
            elif event.key == pygame.K_SPACE:
                title.append(' ')
            elif event.key == pygame.K_TAB:
                return title.append('    ')
            elif event.key == pygame.K_0:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append(')')
                else:
                    title.append('0')
                cursor = cursor + 1
            elif event.key == pygame.K_1:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('!')
                else:
                    title.append('1')
                cursor = cursor + 1
            elif event.key == pygame.K_2:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('@')
                else:
                    title.append('2')
                cursor = cursor + 1
            elif event.key == pygame.K_3:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('#')
                else:
                    title.append('3')
                cursor = cursor + 1
            elif event.key == pygame.K_4:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('$')
                else:
                    title.append('4')
                cursor = cursor + 1
            elif event.key == pygame.K_5:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('%')
                else:
                    title.append('5')
                cursor = cursor + 1
            elif event.key == pygame.K_6:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('^')
                else:
                    title.append('6')
                cursor = cursor + 1
            elif event.key == pygame.K_7:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('&')
                else:
                    title.append('7')
                cursor = cursor + 1
            elif event.key == pygame.K_8:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('*')
                else:
                    title.append('8')
                cursor = cursor + 1
            elif event.key == pygame.K_9:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('(')
                else:
                    title.append('9')
                cursor = cursor + 1
            elif event.key == pygame.K_a:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('A')
                else:
                    title.append('a')
                cursor = cursor + 1
            elif event.key == pygame.K_b:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('B')
                else:
                    title.append('b')
                cursor = cursor + 1
            elif event.key == pygame.K_c:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('C')
                else:
                    title.append('c')
                cursor = cursor + 1
            elif event.key == pygame.K_d:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('D')
                else:
                    title.append('d')
                cursor = cursor + 1
            elif event.key == pygame.K_e:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('E')
                else:
                    title.append('e')
                cursor = cursor + 1
            elif event.key == pygame.K_f:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('F')
                else:
                    title.append('f')
                cursor = cursor + 1
            elif event.key == pygame.K_g:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('G')
                else:
                    title.append('g')
                cursor = cursor + 1
            elif event.key == pygame.K_h:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('H')
                else:
                    title.append('h')
                cursor = cursor + 1
            elif event.key == pygame.K_i:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('I')
                else:
                    title.append('i')
                cursor = cursor + 1
            elif event.key == pygame.K_j:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('J')
                else:
                    title.append('j')
                cursor = cursor + 1
            elif event.key == pygame.K_k:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('K')
                else:
                    title.append('k')
                cursor = cursor + 1
            elif event.key == pygame.K_l:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('L')
                else:
                    title.append('l')
                cursor = cursor + 1
            elif event.key == pygame.K_m:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('M')
                else:
                    title.append('m')
                cursor = cursor + 1
            elif event.key == pygame.K_n:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('N')
                else:
                    title.append('n')
                cursor = cursor + 1
            elif event.key == pygame.K_o:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('O')
                else:
                    title.append('o')
                cursor = cursor + 1
            elif event.key == pygame.K_p:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('P')
                else:
                    title.append('p')
                cursor = cursor + 1
            elif event.key == pygame.K_q:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('Q')
                else:
                    title.append('q')
                cursor = cursor + 1
            elif event.key == pygame.K_r:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('R')
                else:
                    title.append('r')
                cursor = cursor + 1
            elif event.key == pygame.K_s:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('S')
                else:
                    title.append('s')
                cursor = cursor + 1
            elif event.key == pygame.K_t:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('T')
                else:
                    title.append('t')
                cursor = cursor + 1
            elif event.key == pygame.K_u:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('U')
                else:
                    title.append('u')
                cursor = cursor + 1
            elif event.key == pygame.K_v:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('V')
                else:
                    title.append('v')
                cursor = cursor + 1
            elif event.key == pygame.K_w:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('W')
                else:
                    title.append('w')
                cursor = cursor + 1
            elif event.key == pygame.K_x:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('X')
                else:
                    title.append('x')
                cursor = cursor + 1
            elif event.key == pygame.K_y:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('Y')
                else:
                    title.append('y')
                cursor = cursor + 1
            elif event.key == pygame.K_z:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    title.append('Z')
                else:
                    title.append('z')
                cursor = cursor + 1
            elif event.key == pygame.K_QUOTE:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('"')
                else:
                    title.append("'")
                cursor = cursor + 1
            elif event.key == pygame.K_QUOTEDBL:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('"')
                else:
                    title.append("'")
            elif event.key == pygame.K_PLUS:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('+')
                else:
                    title.append('=')
                cursor = cursor + 1
            elif event.key == pygame.K_EQUALS:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('+')
                else:
                    title.append('=')
                cursor = cursor + 1
            elif event.key == pygame.K_MINUS:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('_')
                else:
                    title.append('-')
                cursor = cursor + 1
            elif event.key == pygame.K_PERIOD:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('>')
                else:
                    title.append('.')
                cursor = cursor + 1
            elif event.key == pygame.K_GREATER:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('>')
                else:
                    title.append('.')
                cursor = cursor + 1
            elif event.key == pygame.K_SLASH:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('?')
                else:
                    title.append('/')
                cursor = cursor + 1
            elif event.key == pygame.K_QUESTION:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('?')
                else:
                    title.append('/')
                cursor = cursor + 1
            elif event.key == pygame.K_COLON:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append(':')
                else:
                    title.append(';')
                cursor = cursor + 1
            elif event.key == pygame.K_SEMICOLON:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append(':')
                else:
                    title.append(';')
                cursor = cursor + 1
            elif event.key == pygame.K_LESS:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('<')
                else:
                    title.append(',')
                cursor = cursor + 1
            elif event.key == pygame.K_COMMA:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('<')
                else:
                    title.append(',')
                cursor = cursor + 1
            elif event.key == pygame.K_LEFTBRACKET:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('{')
                else:
                    title.append('[')
                cursor = cursor + 1
            elif event.key == pygame.K_RIGHTBRACKET:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('}')
                else:
                    title.append(']')
                cursor = cursor + 1
            elif event.key == pygame.K_BACKSLASH:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('|')
                else:
                    title.append('\\')
                cursor = cursor + 1

            elif event.key == pygame.K_BACKQUOTE:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    title.append('~')
                else:
                    title.append('`')

