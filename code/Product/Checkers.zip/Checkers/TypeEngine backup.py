import pygame
def typer(mod):
    cursor = 0
    notesnum = 1
    noteslist = [[[]]]
    tot = 0
    for event in pygame.event.get():
        pass
        if event.type == pygame.KEYDOWN:
            mods = mod
            print(mods)
            if event.key == pygame.K_BACKSPACE:
                backspace = True
            elif event.key == pygame.K_SPACE:
                return ' '
            elif event.key == pygame.K_TAB:
                return '    '
            elif event.key == pygame.K_0:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return ')'
                else:
                    return '0'
                cursor = cursor + 1
            elif event.key == pygame.K_1:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '!'
                else:
                    return '1'
                cursor = cursor + 1
            elif event.key == pygame.K_2:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '@'
                else:
                    return '2'
                cursor = cursor + 1
            elif event.key == pygame.K_3:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '#'
                else:
                    return '3'
                cursor = cursor + 1
            elif event.key == pygame.K_4:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '$'
                else:
                    return '4'
                cursor = cursor + 1
            elif event.key == pygame.K_5:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '%'
                else:
                    return '5'
                cursor = cursor + 1
            elif event.key == pygame.K_6:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '^'
                else:
                    return '6'
                cursor = cursor + 1
            elif event.key == pygame.K_7:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '&'
                else:
                    return '7'
                cursor = cursor + 1
            elif event.key == pygame.K_8:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '*'
                else:
                    return '8'
                cursor = cursor + 1
            elif event.key == pygame.K_9:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '('
                else:
                    return '9'
                cursor = cursor + 1
            elif event.key == pygame.K_a:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'A'
                else:
                    return 'a'
                cursor = cursor + 1
            elif event.key == pygame.K_b:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'B'
                else:
                    return 'b'
                cursor = cursor + 1
            elif event.key == pygame.K_c:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'C'
                else:
                    return 'c'
                cursor = cursor + 1
            elif event.key == pygame.K_d:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'D'
                else:
                    return 'd'
                cursor = cursor + 1
            elif event.key == pygame.K_e:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'E'
                else:
                    return 'e'
                cursor = cursor + 1
            elif event.key == pygame.K_f:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'F'
                else:
                    return 'f'
                cursor = cursor + 1
            elif event.key == pygame.K_g:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'G'
                else:
                    return 'g'
                cursor = cursor + 1
            elif event.key == pygame.K_h:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'H'
                else:
                    return 'h'
                cursor = cursor + 1
            elif event.key == pygame.K_i:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'I'
                else:
                    return 'i'
                cursor = cursor + 1
            elif event.key == pygame.K_j:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'J'
                else:
                    return 'j'
                cursor = cursor + 1
            elif event.key == pygame.K_k:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'K'
                else:
                    return 'k'
                cursor = cursor + 1
            elif event.key == pygame.K_l:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'L'
                else:
                    return 'l'
                cursor = cursor + 1
            elif event.key == pygame.K_m:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'M'
                else:
                    return 'm'
                cursor = cursor + 1
            elif event.key == pygame.K_n:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'N'
                else:
                    return 'n'
                cursor = cursor + 1
            elif event.key == pygame.K_o:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'O'
                else:
                    return 'o'
                cursor = cursor + 1
            elif event.key == pygame.K_p:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'P'
                else:
                    return 'p'
                cursor = cursor + 1
            elif event.key == pygame.K_q:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'Q'
                else:
                    return 'q'
                cursor = cursor + 1
            elif event.key == pygame.K_r:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'R'
                else:
                    return 'r'
                cursor = cursor + 1
            elif event.key == pygame.K_s:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'S'
                else:
                    return 's'
                cursor = cursor + 1
            elif event.key == pygame.K_t:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'T'
                else:
                    return 't'
                cursor = cursor + 1
            elif event.key == pygame.K_u:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'U'
                else:
                    return 'u'
                cursor = cursor + 1
            elif event.key == pygame.K_v:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'V'
                else:
                    return 'v'
                cursor = cursor + 1
            elif event.key == pygame.K_w:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'W'
                else:
                    return 'w'
                cursor = cursor + 1
            elif event.key == pygame.K_x:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'X'
                else:
                    return 'x'
                cursor = cursor + 1
            elif event.key == pygame.K_y:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'Y'
                else:
                    return 'y'
                cursor = cursor + 1
            elif event.key == pygame.K_z:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT or mods & pygame.KMOD_CAPS:
                    return 'Z'
                else:
                    return 'z'
                cursor = cursor + 1
            elif event.key == pygame.K_QUOTE:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '"'
                else:
                    return "'"
                cursor = cursor + 1
            elif event.key == pygame.K_QUOTEDBL:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '"'
                else:
                    return "'"
            elif event.key == pygame.K_PLUS:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '+'
                else:
                    return '='
                cursor = cursor + 1
            elif event.key == pygame.K_EQUALS:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '+'
                else:
                    return '='
                cursor = cursor + 1
            elif event.key == pygame.K_MINUS:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '_'
                else:
                    return '-'
                cursor = cursor + 1
            elif event.key == pygame.K_PERIOD:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '>'
                else:
                    return '.'
                cursor = cursor + 1
            elif event.key == pygame.K_GREATER:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '>'
                else:
                    return '.'
                cursor = cursor + 1
            elif event.key == pygame.K_SLASH:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '?'
                else:
                    return '/'
                cursor = cursor + 1
            elif event.key == pygame.K_QUESTION:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '?'
                else:
                    return '/'
                cursor = cursor + 1
            elif event.key == pygame.K_COLON:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return ':'
                else:
                    return ';'
                cursor = cursor + 1
            elif event.key == pygame.K_SEMICOLON:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return ':'
                else:
                    return ';'
                cursor = cursor + 1
            elif event.key == pygame.K_LESS:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '<'
                else:
                    return ','
                cursor = cursor + 1
            elif event.key == pygame.K_COMMA:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '<'
                else:
                    return ','
                cursor = cursor + 1
            elif event.key == pygame.K_LEFTBRACKET:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '{'
                else:
                    return '['
                cursor = cursor + 1
            elif event.key == pygame.K_RIGHTBRACKET:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '}'
                else:
                    return ']'
                cursor = cursor + 1
            elif event.key == pygame.K_BACKSLASH:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '|'
                else:
                    return '\\'
                cursor = cursor + 1

            elif event.key == pygame.K_BACKQUOTE:
                if mods & pygame.KMOD_LSHIFT or mods & pygame.KMOD_RSHIFT:
                    return '~'
                else:
                    return '`'

